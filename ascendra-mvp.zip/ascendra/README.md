# 🚀 Ascendra — MVP v1

> Talabalar va rivojlanayotgan yoshlar uchun premium vazifa, odat va rivojlanish platformasi.

---

## 📋 Loyiha tuzilmasi

```
ascendra/
├── app/
│   ├── auth/
│   │   ├── login/page.tsx          # Kirish sahifasi
│   │   └── register/page.tsx       # Ro'yxatdan o'tish
│   ├── dashboard/
│   │   ├── layout.tsx              # Dashboard layout
│   │   └── page.tsx                # Bosh sahifa
│   ├── vazifalar/
│   │   ├── layout.tsx
│   │   └── page.tsx                # Vazifalar tizimi
│   ├── odatlar/
│   │   ├── layout.tsx
│   │   └── page.tsx                # Odatlar trekeri
│   ├── profil/
│   │   ├── layout.tsx
│   │   └── page.tsx                # Profil sahifasi
│   ├── layout.tsx                  # Root layout
│   ├── page.tsx                    # Redirect
│   └── globals.css                 # Global stillar
├── components/
│   └── layout/
│       ├── Sidebar.tsx             # Desktop sidebar
│       └── BottomNav.tsx           # Mobil navigatsiya
├── lib/
│   ├── supabase/
│   │   ├── client.ts               # Browser client
│   │   └── server.ts               # Server client
│   └── utils.ts                    # Yordamchi funksiyalar
├── types/
│   └── index.ts                    # TypeScript turlari
├── middleware.ts                    # Auth middleware
├── supabase-schema.sql             # Database schema
├── tailwind.config.ts
├── next.config.ts
└── package.json
```

---

## 🗄️ Database Schema

| Jadval | Tavsif |
|--------|---------|
| `profiles` | Foydalanuvchi profili (XP, Level, Streak) |
| `tasks` | Vazifalar (nomi, qiyinlik, muddat) |
| `habits` | Odatlar (nomi, icon, streak) |
| `habit_completions` | Kunlik odat bajarilishi |

---

## ⚙️ O'rnatish bo'yicha qo'llanma

### 1️⃣ Supabase loyihasini yarating

1. [supabase.com](https://supabase.com) ga kiring
2. **New Project** bosing
3. Loyiha nomini kiriting: `ascendra`
4. Ma'lumotlar bazasi parolini kiriting (eslab qoling)
5. Region: **Frankfurt (EU)** yoki **Singapore** tanlang
6. **Create new project** bosing

### 2️⃣ Database schemani o'rnating

1. Supabase Dashboard → **SQL Editor** oching
2. `supabase-schema.sql` faylining barcha mazmunini nusxalang
3. SQL Editor ga joylashtiring va **Run** bosing
4. Xatolik yo'q bo'lsa muvaffaqiyatli!

### 3️⃣ Supabase kalitlarini oling

Supabase Dashboard → **Settings** → **API** ga boring:

```
Project URL:  https://xxxxxxxxxxxx.supabase.co
anon key:     eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 4️⃣ Email tasdiqlashni o'chiring (Dev uchun)

Supabase Dashboard → **Authentication** → **Email** → **Confirm email**: OFF

### 5️⃣ Loyihani klonlang

```bash
# Papkaga kiring
cd ascendra

# Dependencies o'rnating
npm install

# .env.local faylini yarating
cp .env.local.example .env.local
```

### 6️⃣ .env.local ni to'ldiring

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
```

### 7️⃣ Ishga tushiring

```bash
npm run dev
```

Brauzerda oching: **http://localhost:3000**

---

## 🌐 Vercel Deploy qo'llanmasi

### 1️⃣ GitHub ga yuklang

```bash
git init
git add .
git commit -m "feat: Ascendra MVP v1"
git branch -M main
git remote add origin https://github.com/username/ascendra.git
git push -u origin main
```

### 2️⃣ Vercel ga ulang

1. [vercel.com](https://vercel.com) ga kiring
2. **Import Project** → GitHub repongizni tanlang
3. **Framework Preset**: Next.js (avtomatik aniqlanadi)

### 3️⃣ Environment Variables qo'shing

Vercel → **Settings** → **Environment Variables**:

| Nom | Qiymat |
|-----|--------|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://xxx.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | `eyJhbGci...` |

### 4️⃣ Deploy qiling

**Deploy** bosing — 2-3 daqiqada tayyor! 🎉

---

## 🎮 XP Tizimi

| Qiyinlik | XP |
|----------|-----|
| Oson | +10 XP |
| O'rta | +20 XP |
| Qiyin | +40 XP |
| Epik | +80 XP |
| Odat (har biri) | +15 XP |

## 📈 Level Tizimi

```
Level = floor(XP / 100) + 1

0–99 XP    → Level 1 (Yangi boshlagan)
100–299 XP → Level 2-3 (Izlovchi)
300–699 XP → Level 4-7 (Rivojlanuvchi)
700–1199 XP → Level 8-12 (Ustoz)
...
```

---

## 🛠️ Texnologiyalar

- **Frontend**: Next.js 15, TypeScript, Tailwind CSS
- **Backend**: Supabase (Auth, Database, RLS)
- **Database**: PostgreSQL (Supabase)
- **Deploy**: Vercel

---

## 🔒 Xavfsizlik

- Row Level Security (RLS) barcha jadvallarda yoqilgan
- Foydalanuvchi faqat o'z ma'lumotlarini ko'ra oladi
- JWT token orqali autentifikatsiya
- Middleware orqali sahifalar himoyalangan

---

Ascendra | MVP v1.0 | 2025
