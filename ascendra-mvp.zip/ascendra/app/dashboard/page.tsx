import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getTodayString, getLevelTitle, getStreakEmoji } from "@/lib/utils";
import { xpForCurrentLevel, xpToNextLevel, DIFFICULTY_XP } from "@/types";
import { Flame, Star, CheckCircle2, Zap, TrendingUp, Clock } from "lucide-react";
import Link from "next/link";
import { format } from "date-fns";
import { uz } from "date-fns/locale";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/auth/login");

  const today = getTodayString();

  const [{ data: profile }, { data: todayTasks }, { data: allHabits }, { data: todayCompletions }] =
    await Promise.all([
      supabase.from("profiles").select("*").eq("id", user.id).single(),
      supabase
        .from("tasks")
        .select("*")
        .eq("user_id", user.id)
        .or(`due_date.eq.${today},due_date.is.null`)
        .eq("is_completed", false)
        .order("created_at", { ascending: false })
        .limit(5),
      supabase
        .from("habits")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(6),
      supabase
        .from("habit_completions")
        .select("habit_id")
        .eq("user_id", user.id)
        .eq("completed_date", today),
    ]);

  const completedHabitIds = new Set(
    (todayCompletions ?? []).map((c: { habit_id: string }) => c.habit_id)
  );

  const currentXP = profile?.xp ?? 0;
  const currentLevel = profile?.level ?? 1;
  const streak = profile?.streak ?? 0;
  const xpInLevel = xpForCurrentLevel(currentXP);
  const xpToNext = xpToNextLevel(currentXP);
  const levelTitle = getLevelTitle(currentLevel);

  const todayDate = format(new Date(), "d MMMM, yyyy", { locale: uz });
  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 6) return "Xayrli tun";
    if (h < 12) return "Xayrli tong";
    if (h < 18) return "Xayrli kun";
    return "Xayrli kech";
  })();

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <p className="text-text-secondary text-sm">{todayDate}</p>
          <h1 className="text-2xl font-bold text-text-primary mt-0.5">
            {greeting},{" "}
            <span className="text-gradient">
              {profile?.full_name?.split(" ")[0] ?? "Foydalanuvchi"}
            </span>
            !
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <div className="badge border-warning/30 bg-warning/10 text-warning">
            <Flame size={12} />
            {streak} kunlik streak
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Level */}
        <div className="card col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center">
              <Star size={16} className="text-accent" />
            </div>
            <span className="text-xs text-text-tertiary font-mono">DARAJA</span>
          </div>
          <p className="text-3xl font-bold text-text-primary">{currentLevel}</p>
          <p className="text-xs text-text-secondary mt-1">{levelTitle}</p>
          <div className="mt-3">
            <div className="flex justify-between text-xs text-text-tertiary mb-1.5">
              <span>{xpInLevel} XP</span>
              <span>{xpToNext} XP qoldi</span>
            </div>
            <div className="xp-bar">
              <div className="xp-fill" style={{ width: `${xpInLevel}%` }} />
            </div>
          </div>
        </div>

        {/* XP */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-xp/10 rounded-lg flex items-center justify-center">
              <Zap size={16} className="text-xp" />
            </div>
            <span className="text-xs text-text-tertiary font-mono">XP</span>
          </div>
          <p className="text-3xl font-bold text-text-primary">{currentXP}</p>
          <p className="text-xs text-text-secondary mt-1">Jami tajriba</p>
        </div>

        {/* Streak */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
              <Flame size={16} className="text-orange-500" />
            </div>
            <span className="text-xs text-text-tertiary font-mono">STREAK</span>
          </div>
          <p className="text-3xl font-bold text-text-primary">
            {getStreakEmoji(streak)} {streak}
          </p>
          <p className="text-xs text-text-secondary mt-1">Ketma-ket kun</p>
        </div>

        {/* Progress */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-success/10 rounded-lg flex items-center justify-center">
              <TrendingUp size={16} className="text-success" />
            </div>
            <span className="text-xs text-text-tertiary font-mono">BAJARILDI</span>
          </div>
          <p className="text-3xl font-bold text-text-primary">
            {profile?.tasks_completed ?? 0}
          </p>
          <p className="text-xs text-text-secondary mt-1">Jami vazifalar</p>
        </div>
      </div>

      {/* Today's Tasks */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-text-primary flex items-center gap-2">
            <CheckCircle2 size={18} className="text-accent" />
            Bugungi vazifalar
          </h2>
          <Link
            href="/vazifalar"
            className="text-xs text-accent hover:text-accent-hover transition-colors"
          >
            Barchasini ko&apos;rish →
          </Link>
        </div>

        {!todayTasks || todayTasks.length === 0 ? (
          <div className="card flex flex-col items-center justify-center py-10 text-center">
            <CheckCircle2 size={32} className="text-text-tertiary mb-3" />
            <p className="text-text-secondary font-medium">Vazifalar yo&apos;q</p>
            <p className="text-text-tertiary text-sm mt-1">
              Yangi vazifa qo&apos;shing va bugundan boshlang
            </p>
            <Link href="/vazifalar" className="btn-primary mt-4">
              Vazifa qo&apos;shish
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {todayTasks.map((task: {
              id: string;
              title: string;
              difficulty: "oson" | "orta" | "qiyin" | "epik";
              due_date: string | null;
            }) => (
              <div key={task.id} className="card flex items-center gap-3">
                <div className="w-4 h-4 rounded-full border-2 border-border flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-text-primary truncate">
                    {task.title}
                  </p>
                  {task.due_date && (
                    <p className="text-xs text-text-tertiary flex items-center gap-1 mt-0.5">
                      <Clock size={11} />
                      Muddat: {task.due_date}
                    </p>
                  )}
                </div>
                <span className="badge text-xs border-border text-text-tertiary flex-shrink-0">
                  +{DIFFICULTY_XP[task.difficulty]} XP
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Today's Habits */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-semibold text-text-primary flex items-center gap-2">
            <Flame size={18} className="text-orange-500" />
            Bugungi odatlar
          </h2>
          <Link
            href="/odatlar"
            className="text-xs text-accent hover:text-accent-hover transition-colors"
          >
            Barchasini ko&apos;rish →
          </Link>
        </div>

        {!allHabits || allHabits.length === 0 ? (
          <div className="card flex flex-col items-center justify-center py-10 text-center">
            <Target size={32} className="text-text-tertiary mb-3" />
            <p className="text-text-secondary font-medium">Odatlar yo&apos;q</p>
            <p className="text-text-tertiary text-sm mt-1">
              Birinchi odatingizni yarating
            </p>
            <Link href="/odatlar" className="btn-primary mt-4">
              Odat qo&apos;shish
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {allHabits.map((habit: { id: string; name: string; icon: string | null; streak: number }) => {
              const isDone = completedHabitIds.has(habit.id);
              return (
                <div
                  key={habit.id}
                  className={`card transition-all ${
                    isDone ? "border-success/30 bg-success/5" : ""
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="text-xl">
                      {habit.icon ?? "⭐"}
                    </span>
                    {isDone && (
                      <CheckCircle2 size={16} className="text-success" />
                    )}
                  </div>
                  <p className="text-sm font-medium text-text-primary">
                    {habit.name}
                  </p>
                  <p className="text-xs text-text-tertiary mt-1">
                    🔥 {habit.streak} kun
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// Target icon
function Target({ size, className }: { size: number; className: string }) {
  return (
    <svg
      width={size}
      height={size}
      className={className}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <circle cx="12" cy="12" r="6" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}
