import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Ascendra — O'z cho'qqingga chiq",
  description:
    "Talabalar va rivojlanayotgan yoshlar uchun premium vazifa, odat va rivojlanish platformasi.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="uz" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-background text-text-primary antialiased font-sans">
        {children}
      </body>
    </html>
  );
}
