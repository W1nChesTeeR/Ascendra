import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import {
  calculateLevel,
  xpForCurrentLevel,
  xpToNextLevel,
} from "@/types";
import {
  User,
  Star,
  Zap,
  Flame,
  CheckSquare,
  Target,
  Calendar,
  TrendingUp,
} from "lucide-react";
import { getLevelTitle, getStreakEmoji, formatDateFull } from "@/lib/utils";

export default async function ProfilPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/auth/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  const xp = profile?.xp ?? 0;
  const level = calculateLevel(xp);
  const xpInLevel = xpForCurrentLevel(xp);
  const xpToNext = xpToNextLevel(xp);
  const levelTitle = getLevelTitle(level);
  const streak = profile?.streak ?? 0;
  const tasksCompleted = profile?.tasks_completed ?? 0;
  const habitsTotal = profile?.habits_completed_total ?? 0;
  const joinDate = profile?.created_at
    ? formatDateFull(profile.created_at)
    : "—";

  const stats = [
    {
      icon: Star,
      label: "Daraja",
      value: level,
      sub: levelTitle,
      color: "text-accent",
      bg: "bg-accent/10",
    },
    {
      icon: Zap,
      label: "Jami XP",
      value: xp,
      sub: `${xpToNext} XP qoldi`,
      color: "text-xp",
      bg: "bg-xp/10",
    },
    {
      icon: Flame,
      label: "Streak",
      value: `${getStreakEmoji(streak)} ${streak}`,
      sub: "Ketma-ket kun",
      color: "text-orange-500",
      bg: "bg-orange-500/10",
    },
    {
      icon: CheckSquare,
      label: "Bajarilgan vazifalar",
      value: tasksCompleted,
      sub: "Jami",
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      icon: Target,
      label: "Odat bajarilishi",
      value: habitsTotal,
      sub: "Jami marta",
      color: "text-purple-400",
      bg: "bg-purple-400/10",
    },
    {
      icon: TrendingUp,
      label: "Keyingi darajaga",
      value: `${xpInLevel}/100`,
      sub: "XP progress",
      color: "text-text-secondary",
      bg: "bg-surface-hover",
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-text-primary flex items-center gap-2">
          <User size={24} className="text-accent" />
          Profil
        </h1>
        <p className="text-text-secondary text-sm mt-1">
          Sizning rivojlanish statistikangiz
        </p>
      </div>

      {/* Profile card */}
      <div className="card">
        <div className="flex flex-col sm:flex-row sm:items-center gap-5">
          {/* Avatar */}
          <div className="w-16 h-16 bg-accent/10 border-2 border-accent/20 rounded-2xl flex items-center justify-center flex-shrink-0">
            <span className="text-3xl font-bold text-accent">
              {profile?.full_name?.[0]?.toUpperCase() ?? "U"}
            </span>
          </div>

          {/* Info */}
          <div className="flex-1">
            <h2 className="text-xl font-bold text-text-primary">
              {profile?.full_name ?? "Foydalanuvchi"}
            </h2>
            <p className="text-text-secondary text-sm">{user.email}</p>
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              <span className="badge border-accent/30 bg-accent/10 text-accent text-xs">
                <Star size={11} />
                Daraja {level} · {levelTitle}
              </span>
              <span className="flex items-center gap-1 text-xs text-text-tertiary">
                <Calendar size={11} />
                {joinDate} dan beri
              </span>
            </div>
          </div>

          {/* Level XP bar */}
          <div className="sm:w-40">
            <div className="flex justify-between text-xs text-text-tertiary mb-1.5">
              <span>Daraja {level}</span>
              <span>Daraja {level + 1}</span>
            </div>
            <div className="xp-bar h-2">
              <div
                className="xp-fill h-full"
                style={{ width: `${xpInLevel}%` }}
              />
            </div>
            <p className="text-xs text-text-tertiary mt-1.5 text-center">
              {xpToNext} XP qoldi
            </p>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div>
        <h3 className="text-sm font-medium text-text-secondary mb-4 uppercase tracking-wider">
          Statistika
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {stats.map((stat, i) => (
            <div key={i} className="card">
              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-8 h-8 ${stat.bg} rounded-lg flex items-center justify-center`}
                >
                  <stat.icon size={16} className={stat.color} />
                </div>
              </div>
              <p className="text-2xl font-bold text-text-primary">
                {stat.value}
              </p>
              <p className="text-xs text-text-secondary mt-0.5">{stat.label}</p>
              <p className="text-xs text-text-tertiary">{stat.sub}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Level milestones */}
      <div>
        <h3 className="text-sm font-medium text-text-secondary mb-4 uppercase tracking-wider">
          Daraja yo&apos;li
        </h3>
        <div className="card">
          <div className="space-y-3">
            {[
              { lvl: 1, title: "Yangi boshlagan", xp: 0 },
              { lvl: 4, title: "Izlovchi", xp: 300 },
              { lvl: 8, title: "Rivojlanuvchi", xp: 700 },
              { lvl: 13, title: "Ustoz", xp: 1200 },
              { lvl: 21, title: "Ekspert", xp: 2000 },
              { lvl: 31, title: "Legenda", xp: 3000 },
            ].map((milestone) => {
              const isReached = level >= milestone.lvl;
              const isCurrent =
                level >= milestone.lvl &&
                level <
                  (milestone.lvl === 1
                    ? 4
                    : milestone.lvl === 4
                    ? 8
                    : milestone.lvl === 8
                    ? 13
                    : milestone.lvl === 13
                    ? 21
                    : milestone.lvl === 21
                    ? 31
                    : 999);
              return (
                <div
                  key={milestone.lvl}
                  className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                    isCurrent
                      ? "bg-accent/10 border border-accent/20"
                      : isReached
                      ? "opacity-50"
                      : "opacity-30"
                  }`}
                >
                  <div
                    className={`w-2 h-2 rounded-full flex-shrink-0 ${
                      isReached ? "bg-accent" : "bg-border"
                    }`}
                  />
                  <div className="flex-1">
                    <span className="text-sm font-medium text-text-primary">
                      {milestone.title}
                    </span>
                  </div>
                  <span className="text-xs text-text-tertiary font-mono">
                    Daraja {milestone.lvl} · {milestone.xp}+ XP
                  </span>
                  {isCurrent && (
                    <span className="badge border-accent/30 bg-accent/10 text-accent text-xs">
                      Hozir
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
