"use client";

import { useState, useEffect, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import {
  Task,
  Difficulty,
  DIFFICULTY_LABELS,
  DIFFICULTY_XP,
  DIFFICULTY_COLORS,
} from "@/types";
import {
  Plus,
  CheckCircle2,
  Circle,
  Pencil,
  Trash2,
  X,
  Loader2,
  Calendar,
  Filter,
  CheckSquare,
} from "lucide-react";
import { cn, formatDate, getTodayString } from "@/lib/utils";

type FilterType = "all" | "today" | "completed";

export default function VazifalarPage() {
  const supabase = createClient();

  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterType>("all");
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty>("orta");

  const loadTasks = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    let query = supabase
      .from("tasks")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (filter === "today") {
      query = query.eq("due_date", getTodayString()).eq("is_completed", false);
    } else if (filter === "completed") {
      query = query.eq("is_completed", true);
    } else {
      query = query.eq("is_completed", false);
    }

    const { data } = await query;
    setTasks(data ?? []);
    setLoading(false);
  }, [supabase, filter]);

  useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const openCreateModal = () => {
    setEditingTask(null);
    setTitle("");
    setDescription("");
    setDueDate("");
    setDifficulty("orta");
    setShowModal(true);
  };

  const openEditModal = (task: Task) => {
    setEditingTask(task);
    setTitle(task.title);
    setDescription(task.description ?? "");
    setDueDate(task.due_date ?? "");
    setDifficulty(task.difficulty);
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    setSubmitting(true);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    if (editingTask) {
      await supabase
        .from("tasks")
        .update({
          title: title.trim(),
          description: description.trim() || null,
          due_date: dueDate || null,
          difficulty,
          updated_at: new Date().toISOString(),
        })
        .eq("id", editingTask.id);
    } else {
      await supabase.from("tasks").insert({
        user_id: user.id,
        title: title.trim(),
        description: description.trim() || null,
        due_date: dueDate || null,
        difficulty,
      });
    }

    setShowModal(false);
    setSubmitting(false);
    loadTasks();
  };

  const handleComplete = async (task: Task) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const xp = DIFFICULTY_XP[task.difficulty];

    await supabase
      .from("tasks")
      .update({
        is_completed: true,
        completed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq("id", task.id);

    // Update profile XP
    const { data: profile } = await supabase
      .from("profiles")
      .select("xp, level, tasks_completed, streak, last_activity_date")
      .eq("id", user.id)
      .single();

    if (profile) {
      const newXP = profile.xp + xp;
      const newLevel = Math.floor(newXP / 100) + 1;
      const today = getTodayString();
      const lastDate = profile.last_activity_date;
      const newStreak =
        lastDate === today
          ? profile.streak
          : lastDate === new Date(Date.now() - 86400000).toISOString().split("T")[0]
          ? profile.streak + 1
          : 1;

      await supabase
        .from("profiles")
        .update({
          xp: newXP,
          level: newLevel,
          tasks_completed: profile.tasks_completed + 1,
          streak: newStreak,
          last_activity_date: today,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user.id);
    }

    loadTasks();
  };

  const handleDelete = async (taskId: string) => {
    if (!confirm("Bu vazifani o'chirishni xohlaysizmi?")) return;
    await supabase.from("tasks").delete().eq("id", taskId);
    loadTasks();
  };

  const filterLabels: Record<FilterType, string> = {
    all: "Barcha",
    today: "Bugun",
    completed: "Bajarilgan",
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-text-primary flex items-center gap-2">
            <CheckSquare size={24} className="text-accent" />
            Vazifalar
          </h1>
          <p className="text-text-secondary text-sm mt-1">
            Vazifalarni boshqaring va XP to&apos;plang
          </p>
        </div>
        <button onClick={openCreateModal} className="btn-primary">
          <Plus size={16} />
          Vazifa qo&apos;shish
        </button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2">
        <Filter size={14} className="text-text-tertiary" />
        {(["all", "today", "completed"] as FilterType[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
              filter === f
                ? "bg-accent text-white"
                : "bg-surface-hover text-text-secondary hover:text-text-primary border border-border"
            )}
          >
            {filterLabels[f]}
          </button>
        ))}
      </div>

      {/* Tasks list */}
      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 size={24} className="animate-spin text-text-tertiary" />
        </div>
      ) : tasks.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <CheckCircle2 size={36} className="text-text-tertiary mb-3" />
          <p className="text-text-secondary font-medium">
            {filter === "completed" ? "Hali bajarilgan vazifalar yo'q" : "Vazifalar yo'q"}
          </p>
          <p className="text-text-tertiary text-sm mt-1">
            {filter !== "completed" && "Yangi vazifa qo'shing va boshlang"}
          </p>
          {filter !== "completed" && (
            <button onClick={openCreateModal} className="btn-primary mt-4">
              <Plus size={16} />
              Birinchi vazifa
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {tasks.map((task) => (
            <div
              key={task.id}
              className={cn(
                "card group flex items-start gap-3 transition-all",
                task.is_completed && "opacity-60"
              )}
            >
              {/* Complete button */}
              {!task.is_completed && (
                <button
                  onClick={() => handleComplete(task)}
                  className="mt-0.5 flex-shrink-0 text-text-tertiary hover:text-success transition-colors"
                >
                  <Circle size={20} />
                </button>
              )}
              {task.is_completed && (
                <CheckCircle2 size={20} className="text-success flex-shrink-0 mt-0.5" />
              )}

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start gap-2 flex-wrap">
                  <p
                    className={cn(
                      "text-sm font-medium",
                      task.is_completed
                        ? "line-through text-text-tertiary"
                        : "text-text-primary"
                    )}
                  >
                    {task.title}
                  </p>
                  <span
                    className={cn(
                      "badge text-xs flex-shrink-0",
                      DIFFICULTY_COLORS[task.difficulty]
                    )}
                  >
                    {DIFFICULTY_LABELS[task.difficulty]} · +{DIFFICULTY_XP[task.difficulty]} XP
                  </span>
                </div>
                {task.description && (
                  <p className="text-xs text-text-secondary mt-1">
                    {task.description}
                  </p>
                )}
                {task.due_date && (
                  <p className="text-xs text-text-tertiary flex items-center gap-1 mt-1">
                    <Calendar size={11} />
                    {formatDate(task.due_date)}
                  </p>
                )}
              </div>

              {/* Actions */}
              {!task.is_completed && (
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                  <button
                    onClick={() => openEditModal(task)}
                    className="btn-ghost p-1.5 text-text-tertiary"
                  >
                    <Pencil size={14} />
                  </button>
                  <button
                    onClick={() => handleDelete(task.id)}
                    className="btn-ghost p-1.5 text-danger"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-surface-elevated border border-border rounded-2xl p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold text-text-primary">
                {editingTask ? "Vazifani tahrirlash" : "Yangi vazifa"}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="btn-ghost p-1.5 text-text-tertiary"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Vazifa nomi *</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="input-field"
                  placeholder="Nimani bajarasiz?"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="label">Tavsifi</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field resize-none"
                  placeholder="Qo'shimcha ma'lumot..."
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Muddat</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="input-field"
                    min={getTodayString()}
                  />
                </div>
                <div>
                  <label className="label">Qiyinlik</label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as Difficulty)}
                    className="input-field"
                  >
                    {(["oson", "orta", "qiyin", "epik"] as Difficulty[]).map(
                      (d) => (
                        <option key={d} value={d}>
                          {DIFFICULTY_LABELS[d]} (+{DIFFICULTY_XP[d]} XP)
                        </option>
                      )
                    )}
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn-secondary flex-1"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  disabled={submitting || !title.trim()}
                  className="btn-primary flex-1"
                >
                  {submitting ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : editingTask ? (
                    "Saqlash"
                  ) : (
                    "Qo'shish"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
