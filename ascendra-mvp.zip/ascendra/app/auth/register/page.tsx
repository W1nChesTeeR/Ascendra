"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Zap, Eye, EyeOff, ArrowRight, Loader2 } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const supabase = createClient();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (password.length < 6) {
      setError("Parol kamida 6 ta belgidan iborat bo'lishi kerak.");
      setLoading(false);
      return;
    }

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: fullName },
      },
    });

    if (signUpError) {
      setError("Ro'yxatdan o'tishda xatolik. Qaytadan urinib ko'ring.");
      setLoading(false);
      return;
    }

    if (data.user) {
      // Create profile
      await supabase.from("profiles").upsert({
        id: data.user.id,
        full_name: fullName,
        xp: 0,
        level: 1,
        streak: 0,
        tasks_completed: 0,
        habits_completed_total: 0,
      });

      // Auto-login in dev mode (no email confirmation)
      if (data.session) {
        router.push("/dashboard");
        router.refresh();
      } else {
        setSuccess(true);
      }
    }

    setLoading(false);
  };

  if (success) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center max-w-sm animate-fade-in">
          <div className="w-14 h-14 bg-success/10 border border-success/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">✓</span>
          </div>
          <h2 className="text-xl font-bold text-text-primary mb-2">
            Muvaffaqiyatli ro&apos;yxatdan o&apos;tdingiz!
          </h2>
          <p className="text-text-secondary text-sm">
            Email manzilingizni tasdiqlang va kirish sahifasiga o&apos;ting.
          </p>
          <Link href="/auth/login" className="btn-primary mt-6 inline-flex">
            Kirish sahifasiga o&apos;ting
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-sm relative animate-fade-in">
        {/* Logo */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-accent/10 border border-accent/20 rounded-xl mb-4">
            <Zap size={22} className="text-accent" />
          </div>
          <h1 className="text-2xl font-bold text-text-primary tracking-tight">
            Ascendra
          </h1>
          <p className="text-text-secondary text-sm mt-1">
            Sayohatingizni boshlang
          </p>
        </div>

        <div className="bg-surface-elevated border border-border rounded-2xl p-7">
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-text-primary">
              Ro&apos;yxatdan o&apos;tish
            </h2>
            <p className="text-text-secondary text-sm mt-0.5">
              Yangi hisob yarating va boshlang
            </p>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div>
              <label className="label">To&apos;liq ism</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="input-field"
                placeholder="Ism Familiya"
                required
              />
            </div>

            <div>
              <label className="label">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field"
                placeholder="sizning@email.uz"
                required
                autoComplete="email"
              />
            </div>

            <div>
              <label className="label">Parol</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field pr-10"
                  placeholder="Kamida 6 ta belgi"
                  required
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-text-tertiary hover:text-text-secondary transition-colors"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-danger/10 border border-danger/20 rounded-lg p-3 text-sm text-danger">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full mt-2"
            >
              {loading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <>
                  Hisob yaratish
                  <ArrowRight size={16} />
                </>
              )}
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-text-secondary mt-6">
          Hisobingiz bormi?{" "}
          <Link
            href="/auth/login"
            className="text-accent hover:text-accent-hover font-medium transition-colors"
          >
            Kirish
          </Link>
        </p>
      </div>
    </div>
  );
}
