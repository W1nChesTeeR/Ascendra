"use client";

import { useState, useEffect, useCallback } from "react";
import { createClient } from "@/lib/supabase/client";
import { Habit } from "@/types";
import {
  Plus,
  CheckCircle2,
  Circle,
  Pencil,
  Trash2,
  X,
  Loader2,
  Flame,
  Target,
} from "lucide-react";
import { cn, getTodayString } from "@/lib/utils";

const HABIT_XP = 15;

const ICONS = [
  "📚", "💻", "🏃", "💧", "🎯", "🧘", "🎸", "✍️",
  "🌍", "🏋️", "🍎", "☕", "🎨", "🔬", "📖", "🎵",
];

export default function OdatlarPage() {
  const supabase = createClient();

  const [habits, setHabits] = useState<Habit[]>([]);
  const [completedIds, setCompletedIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Form
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [icon, setIcon] = useState("⭐");

  const loadHabits = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const today = getTodayString();

    const [{ data: habitsData }, { data: completions }] = await Promise.all([
      supabase
        .from("habits")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false }),
      supabase
        .from("habit_completions")
        .select("habit_id")
        .eq("user_id", user.id)
        .eq("completed_date", today),
    ]);

    setHabits(habitsData ?? []);
    setCompletedIds(
      new Set((completions ?? []).map((c: { habit_id: string }) => c.habit_id))
    );
    setLoading(false);
  }, [supabase]);

  useEffect(() => {
    loadHabits();
  }, [loadHabits]);

  const openCreateModal = () => {
    setEditingHabit(null);
    setName("");
    setDescription("");
    setIcon("⭐");
    setShowModal(true);
  };

  const openEditModal = (habit: Habit) => {
    setEditingHabit(habit);
    setName(habit.name);
    setDescription(habit.description ?? "");
    setIcon(habit.icon ?? "⭐");
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setSubmitting(true);

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setSubmitting(false); return; }

    if (editingHabit) {
      await supabase
        .from("habits")
        .update({
          name: name.trim(),
          description: description.trim() || null,
          icon,
          updated_at: new Date().toISOString(),
        })
        .eq("id", editingHabit.id);
    } else {
      await supabase.from("habits").insert({
        user_id: user.id,
        name: name.trim(),
        description: description.trim() || null,
        icon,
        streak: 0,
      });
    }

    setShowModal(false);
    setSubmitting(false);
    loadHabits();
  };

  const handleComplete = async (habit: Habit) => {
    if (completedIds.has(habit.id)) return;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const today = getTodayString();
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];

    // Insert completion
    await supabase.from("habit_completions").insert({
      habit_id: habit.id,
      user_id: user.id,
      completed_date: today,
    });

    // Update habit streak
    const newStreak =
      habit.last_completed_date === yesterday ? habit.streak + 1 : 1;

    await supabase
      .from("habits")
      .update({
        streak: newStreak,
        last_completed_date: today,
        updated_at: new Date().toISOString(),
      })
      .eq("id", habit.id);

    // Update profile XP + streak
    const { data: profile } = await supabase
      .from("profiles")
      .select("xp, level, habits_completed_total, streak, last_activity_date")
      .eq("id", user.id)
      .single();

    if (profile) {
      const newXP = profile.xp + HABIT_XP;
      const newLevel = Math.floor(newXP / 100) + 1;
      const lastDate = profile.last_activity_date;
      const newProfileStreak =
        lastDate === today
          ? profile.streak
          : lastDate === yesterday
          ? profile.streak + 1
          : 1;

      await supabase
        .from("profiles")
        .update({
          xp: newXP,
          level: newLevel,
          habits_completed_total: profile.habits_completed_total + 1,
          streak: newProfileStreak,
          last_activity_date: today,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user.id);
    }

    loadHabits();
  };

  const handleDelete = async (habitId: string) => {
    if (!confirm("Bu odatni o'chirishni xohlaysizmi?")) return;
    await supabase.from("habits").delete().eq("id", habitId);
    loadHabits();
  };

  const completedCount = habits.filter((h) => completedIds.has(h.id)).length;
  const totalCount = habits.length;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-text-primary flex items-center gap-2">
            <Target size={24} className="text-orange-500" />
            Odatlar
          </h1>
          <p className="text-text-secondary text-sm mt-1">
            Kunlik odatlaringizni kuzating — har biri +{HABIT_XP} XP
          </p>
        </div>
        <button onClick={openCreateModal} className="btn-primary">
          <Plus size={16} />
          Odat qo&apos;shish
        </button>
      </div>

      {/* Today progress */}
      {totalCount > 0 && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-medium text-text-primary">
                Bugungi natija
              </p>
              <p className="text-text-secondary text-xs mt-0.5">
                {completedCount} / {totalCount} odat bajarildi
              </p>
            </div>
            <span className="text-2xl font-bold text-text-primary">
              {completedCount === totalCount && totalCount > 0 ? "🎉" : "🔥"}
              {Math.round((completedCount / totalCount) * 100)}%
            </span>
          </div>
          <div className="xp-bar h-2">
            <div
              className="xp-fill h-full"
              style={{
                width: `${Math.round((completedCount / totalCount) * 100)}%`,
              }}
            />
          </div>
        </div>
      )}

      {/* Habits grid */}
      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 size={24} className="animate-spin text-text-tertiary" />
        </div>
      ) : habits.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <span className="text-4xl mb-3">🎯</span>
          <p className="text-text-secondary font-medium">Odatlar yo&apos;q</p>
          <p className="text-text-tertiary text-sm mt-1">
            Birinchi odatingizni yarating va kunlik streakni boshlang
          </p>
          <button onClick={openCreateModal} className="btn-primary mt-4">
            <Plus size={16} />
            Birinchi odat
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {habits.map((habit) => {
            const isDone = completedIds.has(habit.id);
            return (
              <div
                key={habit.id}
                className={cn(
                  "card group transition-all duration-200",
                  isDone
                    ? "border-success/30 bg-success/5"
                    : "hover:border-border hover:bg-surface-hover"
                )}
              >
                <div className="flex items-start justify-between mb-3">
                  <span className="text-3xl">{habit.icon ?? "⭐"}</span>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {!isDone && (
                      <button
                        onClick={() => openEditModal(habit)}
                        className="btn-ghost p-1.5 text-text-tertiary"
                      >
                        <Pencil size={13} />
                      </button>
                    )}
                    <button
                      onClick={() => handleDelete(habit.id)}
                      className="btn-ghost p-1.5 text-danger"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                <p className="font-medium text-text-primary text-sm mb-0.5">
                  {habit.name}
                </p>
                {habit.description && (
                  <p className="text-xs text-text-secondary mb-2">
                    {habit.description}
                  </p>
                )}

                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-1 text-xs text-text-tertiary">
                    <Flame size={12} className="text-orange-500" />
                    {habit.streak} kunlik streak
                  </div>

                  {isDone ? (
                    <div className="flex items-center gap-1 text-xs text-success font-medium">
                      <CheckCircle2 size={14} />
                      Bajarildi
                    </div>
                  ) : (
                    <button
                      onClick={() => handleComplete(habit)}
                      className="flex items-center gap-1 text-xs font-medium text-text-secondary hover:text-success transition-colors"
                    >
                      <Circle size={14} />
                      Bajarish
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-surface-elevated border border-border rounded-2xl p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold text-text-primary">
                {editingHabit ? "Odatni tahrirlash" : "Yangi odat"}
              </h2>
              <button
                onClick={() => setShowModal(false)}
                className="btn-ghost p-1.5 text-text-tertiary"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Icon picker */}
              <div>
                <label className="label">Belgi tanlang</label>
                <div className="grid grid-cols-8 gap-1.5">
                  {ICONS.map((i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setIcon(i)}
                      className={cn(
                        "w-9 h-9 text-lg rounded-lg flex items-center justify-center transition-all",
                        icon === i
                          ? "bg-accent/20 border border-accent/40"
                          : "bg-surface hover:bg-surface-hover border border-border"
                      )}
                    >
                      {i}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Odat nomi *</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input-field"
                  placeholder="Masalan: Ingliz tili, Kitob o'qish..."
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="label">Tavsifi</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="input-field"
                  placeholder="Qo'shimcha ma'lumot..."
                />
              </div>

              <div className="flex gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn-secondary flex-1"
                >
                  Bekor qilish
                </button>
                <button
                  type="submit"
                  disabled={submitting || !name.trim()}
                  className="btn-primary flex-1"
                >
                  {submitting ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : editingHabit ? (
                    "Saqlash"
                  ) : (
                    "Qo'shish"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
