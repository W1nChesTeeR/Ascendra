export type Difficulty = "oson" | "orta" | "qiyin" | "epik";

export const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  oson: "Oson",
  orta: "O'rta",
  qiyin: "Qiyin",
  epik: "Epik",
};

export const DIFFICULTY_XP: Record<Difficulty, number> = {
  oson: 10,
  orta: 20,
  qiyin: 40,
  epik: 80,
};

export const DIFFICULTY_COLORS: Record<Difficulty, string> = {
  oson: "text-success border-success/30 bg-success/10",
  orta: "text-accent border-accent/30 bg-accent/10",
  qiyin: "text-warning border-warning/30 bg-warning/10",
  epik: "text-epic border-epic/30 bg-epic/10",
};

export interface Profile {
  id: string;
  full_name: string | null;
  avatar_url: string | null;
  xp: number;
  level: number;
  streak: number;
  last_activity_date: string | null;
  tasks_completed: number;
  habits_completed_total: number;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  difficulty: Difficulty;
  due_date: string | null;
  is_completed: boolean;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  icon: string | null;
  streak: number;
  last_completed_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface HabitCompletion {
  id: string;
  habit_id: string;
  user_id: string;
  completed_date: string;
  created_at: string;
}

export interface DashboardStats {
  level: number;
  xp: number;
  xpToNextLevel: number;
  streak: number;
  todayTasks: Task[];
  todayHabits: Habit[];
  completedHabitIds: string[];
}

// XP calculation
export function calculateLevel(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

export function xpForCurrentLevel(xp: number): number {
  return xp % 100;
}

export function xpToNextLevel(xp: number): number {
  return 100 - xpForCurrentLevel(xp);
}

export function xpProgressPercent(xp: number): number {
  return xpForCurrentLevel(xp);
}
