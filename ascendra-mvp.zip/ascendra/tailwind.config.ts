import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Ascendra Design System
        background: "#0A0A0B",
        surface: "#111113",
        "surface-elevated": "#16161A",
        "surface-hover": "#1E1E24",
        border: "#2A2A32",
        "border-subtle": "#1E1E24",
        
        // Electric Blue accent
        accent: {
          DEFAULT: "#3B82F6",
          hover: "#2563EB",
          subtle: "#1E3A6A",
          foreground: "#FFFFFF",
        },
        
        // Text
        "text-primary": "#F1F1F3",
        "text-secondary": "#8B8B9A",
        "text-tertiary": "#5A5A6B",
        
        // Semantic
        success: {
          DEFAULT: "#10B981",
          subtle: "#052e16",
        },
        warning: {
          DEFAULT: "#F59E0B",
          subtle: "#2D1F00",
        },
        danger: {
          DEFAULT: "#EF4444",
          subtle: "#2D0909",
        },
        
        // XP/Level colors
        xp: "#F59E0B",
        epic: "#A855F7",
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      borderRadius: {
        DEFAULT: "8px",
        sm: "6px",
        md: "8px",
        lg: "12px",
        xl: "16px",
        "2xl": "20px",
      },
      boxShadow: {
        "card": "0 1px 3px rgba(0,0,0,0.4), 0 1px 2px rgba(0,0,0,0.3)",
        "card-hover": "0 4px 12px rgba(0,0,0,0.5)",
        "accent-glow": "0 0 20px rgba(59,130,246,0.15)",
        "blue-glow": "0 0 30px rgba(59,130,246,0.2)",
      },
      animation: {
        "fade-in": "fadeIn 0.3s ease-out",
        "slide-up": "slideUp 0.3s ease-out",
        "pulse-slow": "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { transform: "translateY(10px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
