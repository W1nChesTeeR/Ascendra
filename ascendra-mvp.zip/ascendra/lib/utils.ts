import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, isToday, parseISO } from "date-fns";
import { uz } from "date-fns/locale";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: string | Date): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  if (isToday(d)) return "Bugun";
  return format(d, "d MMMM", { locale: uz });
}

export function formatDateFull(date: string | Date): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  return format(d, "d MMMM yyyy", { locale: uz });
}

export function getTodayString(): string {
  return format(new Date(), "yyyy-MM-dd");
}

export function formatRelativeDate(date: string): string {
  const d = parseISO(date);
  if (isToday(d)) return "Bugun";
  return format(d, "d MMM", { locale: uz });
}

export function getLevelTitle(level: number): string {
  if (level <= 3) return "Yangi boshlagan";
  if (level <= 7) return "Izlovchi";
  if (level <= 12) return "Rivojlanuvchi";
  if (level <= 20) return "Ustoz";
  if (level <= 30) return "Ekspert";
  return "Legenda";
}

export function getStreakEmoji(streak: number): string {
  if (streak === 0) return "💤";
  if (streak < 3) return "🔥";
  if (streak < 7) return "⚡";
  if (streak < 14) return "🌟";
  if (streak < 30) return "🚀";
  return "👑";
}
