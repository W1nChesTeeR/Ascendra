"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import {
  LayoutDashboard,
  CheckSquare,
  Target,
  User,
  Zap,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Profile } from "@/types";

interface SidebarProps {
  profile: Profile | null;
}

const navItems = [
  { href: "/dashboard", label: "Bosh sahifa", icon: LayoutDashboard },
  { href: "/vazifalar", label: "Vazifalar", icon: CheckSquare },
  { href: "/odatlar", label: "Odatlar", icon: Target },
  { href: "/profil", label: "Profil", icon: User },
];

export default function Sidebar({ profile }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createClient();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/auth/login");
    router.refresh();
  };

  const xpInCurrentLevel = (profile?.xp ?? 0) % 100;

  return (
    <aside className="fixed left-0 top-0 h-full w-56 bg-surface border-r border-border flex flex-col z-40">
      {/* Logo */}
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-accent/10 border border-accent/20 rounded-lg flex items-center justify-center flex-shrink-0">
            <Zap size={16} className="text-accent" />
          </div>
          <span className="font-bold text-text-primary tracking-tight">
            Ascendra
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-0.5">
        {navItems.map((item) => {
          const isActive =
            pathname === item.href ||
            (item.href !== "/dashboard" && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                isActive ? "nav-link-active" : "nav-link"
              )}
            >
              <item.icon size={18} className={isActive ? "text-accent" : ""} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* User info */}
      {profile && (
        <div className="p-3 border-t border-border">
          {/* XP Bar */}
          <div className="px-1 mb-3">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-text-tertiary font-mono">
                Daraja {profile.level}
              </span>
              <span className="text-text-tertiary font-mono">
                {profile.xp} XP
              </span>
            </div>
            <div className="xp-bar">
              <div
                className="xp-fill"
                style={{ width: `${xpInCurrentLevel}%` }}
              />
            </div>
          </div>

          {/* User */}
          <div className="flex items-center gap-2.5 px-2 py-2 rounded-lg">
            <div className="w-7 h-7 bg-accent/10 border border-accent/20 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold text-accent">
              {profile.full_name?.[0]?.toUpperCase() ?? "U"}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-text-primary truncate">
                {profile.full_name ?? "Foydalanuvchi"}
              </p>
              <p className="text-xs text-text-tertiary">
                🔥 {profile.streak} kun
              </p>
            </div>
            <button
              onClick={handleLogout}
              className="text-text-tertiary hover:text-danger transition-colors p-1 rounded"
              title="Chiqish"
            >
              <LogOut size={14} />
            </button>
          </div>
        </div>
      )}
    </aside>
  );
}
