// ─── Difficulty ──────────────────────────────────────────────────────────────
export type Difficulty = "oson" | "orta" | "qiyin" | "epik";

export const DIFFICULTY_XP: Record<Difficulty, number> = {
  oson: 10,
  orta: 20,
  qiyin: 40,
  epik: 80,
};

export const DIFFICULTY_LABEL: Record<Difficulty, string> = {
  oson: "Oson",
  orta: "O'rta",
  qiyin: "Qiyin",
  epik: "Epik",
};

export const DIFFICULTY_COLOR: Record<Difficulty, string> = {
  oson: "text-emerald-400 bg-emerald-500/10 border-emerald-500/25",
  orta: "text-blue-400 bg-blue-500/10 border-blue-500/25",
  qiyin: "text-amber-400 bg-amber-500/10 border-amber-500/25",
  epik: "text-purple-400 bg-purple-500/10 border-purple-500/25",
};

export const HABIT_XP = 15;

// ─── Database models ──────────────────────────────────────────────────────────
export interface Profile {
  id: string;
  full_name: string | null;
  xp: number;
  level: number;
  streak: number;
  last_activity_date: string | null;
  tasks_completed: number;
  habits_completed_total: number;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  difficulty: Difficulty;
  due_date: string | null;
  is_completed: boolean;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  icon: string | null;
  streak: number;
  last_completed_date: string | null;
  created_at: string;
  updated_at: string;
}

// ─── XP / Level helpers ───────────────────────────────────────────────────────
export function calcLevel(xp: number): number {
  return Math.floor(xp / 100) + 1;
}

export function xpInLevel(xp: number): number {
  return xp % 100;
}

export function xpToNext(xp: number): number {
  return 100 - (xp % 100);
}

export function getLevelTitle(level: number): string {
  if (level <= 2) return "Yangi boshlagan";
  if (level <= 5) return "Izlovchi";
  if (level <= 10) return "Rivojlanuvchi";
  if (level <= 18) return "Ustoz";
  if (level <= 30) return "Ekspert";
  return "Legenda";
}

export function streakEmoji(streak: number): string {
  if (streak === 0) return "💤";
  if (streak < 7) return "🔥";
  if (streak < 14) return "⚡";
  if (streak < 30) return "🌟";
  return "👑";
}

// ─── Date helpers ─────────────────────────────────────────────────────────────
export function todayStr(): string {
  return new Date().toISOString().split("T")[0];
}

export function yesterdayStr(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().split("T")[0];
}

const MONTHS = [
  "Yanvar","Fevral","Mart","Aprel","May","Iyun",
  "Iyul","Avgust","Sentabr","Oktabr","Noyabr","Dekabr",
];

export function fmtDate(s: string): string {
  if (s === todayStr()) return "Bugun";
  const d = new Date(s + "T00:00:00");
  return `${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

export function fmtDateFull(s: string): string {
  const d = new Date(s);
  return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function greeting(): string {
  const h = new Date().getHours();
  if (h < 6)  return "Xayrli tun";
  if (h < 12) return "Xayrli tong";
  if (h < 18) return "Xayrli kun";
  return "Xayrli kech";
}
