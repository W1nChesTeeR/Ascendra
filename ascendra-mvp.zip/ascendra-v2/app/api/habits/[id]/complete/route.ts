import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { HABIT_XP, todayStr, yesterdayStr } from "@/types";

type Params = { params: Promise<{ id: string }> };

// POST /api/habits/[id]/complete — mark habit as done for today
export async function POST(_request: NextRequest, { params }: Params) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });

  const today     = todayStr();
  const yesterday = yesterdayStr();

  // 1. Check if already completed today
  const { data: existing } = await supabase
    .from("habit_completions")
    .select("id")
    .eq("habit_id", id)
    .eq("user_id", user.id)
    .eq("completed_date", today)
    .maybeSingle();

  if (existing) {
    return NextResponse.json({ error: "Bugun allaqachon bajarilgan" }, { status: 400 });
  }

  // 2. Get current habit (for streak calculation)
  const { data: habit, error: habitErr } = await supabase
    .from("habits")
    .select("streak, last_completed_date")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (habitErr || !habit) {
    return NextResponse.json({ error: "Odat topilmadi" }, { status: 404 });
  }

  // 3. Insert completion record
  const { error: insertErr } = await supabase
    .from("habit_completions")
    .insert({ habit_id: id, user_id: user.id, completed_date: today });

  if (insertErr) {
    return NextResponse.json({ error: insertErr.message }, { status: 500 });
  }

  // 4. Update habit streak
  const lastDone = habit.last_completed_date;
  let newHabitStreak = 1;

  if (lastDone === yesterday) {
    newHabitStreak = (habit.streak ?? 0) + 1;
  } else if (lastDone === today) {
    newHabitStreak = habit.streak ?? 1;
  }

  await supabase
    .from("habits")
    .update({
      streak:               newHabitStreak,
      last_completed_date:  today,
      updated_at:           new Date().toISOString(),
    })
    .eq("id", id)
    .eq("user_id", user.id);

  // 5. Add XP to profile
  const { data: profile } = await supabase
    .from("profiles")
    .select("xp, level, streak, last_activity_date, habits_completed_total")
    .eq("id", user.id)
    .single();

  if (profile) {
    const newXP    = (profile.xp ?? 0) + HABIT_XP;
    const newLevel = Math.floor(newXP / 100) + 1;

    // Profile streak
    let newProfileStreak = profile.streak ?? 0;
    const last = profile.last_activity_date;

    if (!last || last < yesterday) {
      newProfileStreak = 1;
    } else if (last === yesterday) {
      newProfileStreak = (profile.streak ?? 0) + 1;
    }
    // If last === today: streak already updated

    await supabase
      .from("profiles")
      .update({
        xp:                    newXP,
        level:                 newLevel,
        streak:                newProfileStreak,
        last_activity_date:    today,
        habits_completed_total:(profile.habits_completed_total ?? 0) + 1,
        updated_at:            new Date().toISOString(),
      })
      .eq("id", user.id);
  }

  return NextResponse.json({ success: true, xpGained: HABIT_XP, habitStreak: newHabitStreak });
}
