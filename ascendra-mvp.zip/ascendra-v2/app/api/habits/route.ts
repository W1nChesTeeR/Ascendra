import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { todayStr } from "@/types";

// GET /api/habits  — returns habits + today's completions
export async function GET(_request: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });
  }

  const today = todayStr();

  const [{ data: habits, error: hErr }, { data: completions, error: cErr }] =
    await Promise.all([
      supabase
        .from("habits")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false }),
      supabase
        .from("habit_completions")
        .select("habit_id")
        .eq("user_id", user.id)
        .eq("completed_date", today),
    ]);

  if (hErr) return NextResponse.json({ error: hErr.message }, { status: 500 });
  if (cErr) return NextResponse.json({ error: cErr.message }, { status: 500 });

  const completedIds = new Set((completions ?? []).map((c: { habit_id: string }) => c.habit_id));

  const result = (habits ?? []).map(h => ({
    ...h,
    completed_today: completedIds.has(h.id),
  }));

  return NextResponse.json(result);
}

// POST /api/habits  — create new habit
export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });
  }

  const body = await request.json() as {
    name: string;
    description?: string;
    icon?: string;
  };

  if (!body.name?.trim()) {
    return NextResponse.json({ error: "Nom majburiy" }, { status: 400 });
  }

  const { data, error } = await supabase
    .from("habits")
    .insert({
      user_id:     user.id,
      name:        body.name.trim(),
      description: body.description?.trim() || null,
      icon:        body.icon ?? "⭐",
      streak:      0,
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ ...data, completed_today: false }, { status: 201 });
}
