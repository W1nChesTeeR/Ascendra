import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { Difficulty } from "@/types";

// GET /api/tasks?filter=all|today|completed
export async function GET(request: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });
  }

  const filter = request.nextUrl.searchParams.get("filter") ?? "all";
  const today  = new Date().toISOString().split("T")[0];

  let query = supabase
    .from("tasks")
    .select("*")
    .eq("user_id", user.id);

  if (filter === "today") {
    query = query
      .eq("due_date", today)
      .eq("is_completed", false);
  } else if (filter === "completed") {
    query = query.eq("is_completed", true);
  } else {
    // "all" = active tasks
    query = query.eq("is_completed", false);
  }

  const { data, error } = await query.order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data ?? []);
}

// POST /api/tasks  — create new task
export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });
  }

  const body = await request.json() as {
    title: string;
    description?: string;
    difficulty?: Difficulty;
    due_date?: string;
  };

  if (!body.title?.trim()) {
    return NextResponse.json({ error: "Sarlavha majburiy" }, { status: 400 });
  }

  const { data, error } = await supabase
    .from("tasks")
    .insert({
      user_id:     user.id,
      title:       body.title.trim(),
      description: body.description?.trim() || null,
      difficulty:  body.difficulty ?? "orta",
      due_date:    body.due_date || null,
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data, { status: 201 });
}
