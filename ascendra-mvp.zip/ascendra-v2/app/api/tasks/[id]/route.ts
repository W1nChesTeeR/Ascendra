import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { Difficulty, DIFFICULTY_XP, todayStr, yesterdayStr } from "@/types";

type Params = { params: Promise<{ id: string }> };

// ─── PUT  /api/tasks/[id]  ─ update task ─────────────────────────────────────
export async function PUT(request: NextRequest, { params }: Params) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });

  const body = await request.json() as {
    title?: string;
    description?: string;
    difficulty?: Difficulty;
    due_date?: string;
  };

  const { data, error } = await supabase
    .from("tasks")
    .update({
      title:       body.title?.trim(),
      description: body.description?.trim() || null,
      difficulty:  body.difficulty,
      due_date:    body.due_date || null,
      updated_at:  new Date().toISOString(),
    })
    .eq("id", id)
    .eq("user_id", user.id)
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}

// ─── DELETE /api/tasks/[id] ──────────────────────────────────────────────────
export async function DELETE(_request: NextRequest, { params }: Params) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });

  const { error } = await supabase
    .from("tasks")
    .delete()
    .eq("id", id)
    .eq("user_id", user.id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ success: true });
}

// ─── PATCH /api/tasks/[id]  ─ mark complete (adds XP) ────────────────────────
export async function PATCH(_request: NextRequest, { params }: Params) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Ruxsat yo'q" }, { status: 401 });

  // 1. Get task to know difficulty
  const { data: task, error: taskErr } = await supabase
    .from("tasks")
    .select("difficulty, is_completed")
    .eq("id", id)
    .eq("user_id", user.id)
    .single();

  if (taskErr || !task) {
    return NextResponse.json({ error: "Vazifa topilmadi" }, { status: 404 });
  }

  if (task.is_completed) {
    return NextResponse.json({ error: "Allaqachon bajarilgan" }, { status: 400 });
  }

  // 2. Mark task complete
  const now = new Date().toISOString();
  const { error: updateErr } = await supabase
    .from("tasks")
    .update({ is_completed: true, completed_at: now, updated_at: now })
    .eq("id", id)
    .eq("user_id", user.id);

  if (updateErr) {
    return NextResponse.json({ error: updateErr.message }, { status: 500 });
  }

  // 3. Add XP to profile
  const xpGained = DIFFICULTY_XP[task.difficulty as Difficulty] ?? 20;
  await addXPToProfile(supabase, user.id, xpGained, "task");

  return NextResponse.json({ success: true, xpGained });
}

// ─── Shared XP helper ─────────────────────────────────────────────────────────
// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function addXPToProfile(supabase: any, userId: string, xpGained: number, source: "task" | "habit") {
  const { data: profile, error } = await supabase
    .from("profiles")
    .select("xp, level, streak, last_activity_date, tasks_completed, habits_completed_total")
    .eq("id", userId)
    .single();

  if (error || !profile) return;

  const today     = todayStr();
  const yesterday = yesterdayStr();

  const newXP    = (profile.xp ?? 0) + xpGained;
  const newLevel = Math.floor(newXP / 100) + 1;

  // Streak logic
  let newStreak = profile.streak ?? 0;
  const last = profile.last_activity_date;

  if (!last || last < yesterday) {
    // No activity yesterday → reset streak
    newStreak = 1;
  } else if (last === yesterday) {
    // Consecutive day → extend streak
    newStreak = (profile.streak ?? 0) + 1;
  }
  // If last === today: already counted today, streak stays

  const updates: Record<string, unknown> = {
    xp:                  newXP,
    level:               newLevel,
    streak:              newStreak,
    last_activity_date:  today,
    updated_at:          new Date().toISOString(),
  };

  if (source === "task") {
    updates.tasks_completed = (profile.tasks_completed ?? 0) + 1;
  } else {
    updates.habits_completed_total = (profile.habits_completed_total ?? 0) + 1;
  }

  await supabase.from("profiles").update(updates).eq("id", userId);
}
