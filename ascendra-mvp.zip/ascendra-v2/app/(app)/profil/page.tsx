import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import {
  Profile,
  calcLevel, xpInLevel, xpToNext,
  getLevelTitle, streakEmoji, fmtDateFull,
} from "@/types";
import {
  User, Star, Zap, Flame, CheckSquare, Target, Calendar,
} from "lucide-react";

export default async function ProfilPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single<Profile>();

  const xp           = profile?.xp                   ?? 0;
  const level        = calcLevel(xp);
  const pct          = xpInLevel(xp);
  const toNext       = xpToNext(xp);
  const streak       = profile?.streak                ?? 0;
  const tasksTotal   = profile?.tasks_completed       ?? 0;
  const habitsTotal  = profile?.habits_completed_total ?? 0;
  const joinDate     = profile?.created_at ? fmtDateFull(profile.created_at) : "—";
  const levelTitle   = getLevelTitle(level);
  const initial      = (profile?.full_name?.[0] ?? "U").toUpperCase();

  const MILESTONES = [
    { from: 1,  to: 3,   title: "Yangi boshlagan", color: "text-zinc-400" },
    { from: 4,  to: 6,   title: "Izlovchi",         color: "text-blue-400" },
    { from: 7,  to: 11,  title: "Rivojlanuvchi",     color: "text-emerald-400" },
    { from: 12, to: 19,  title: "Ustoz",             color: "text-amber-400" },
    { from: 20, to: 31,  title: "Ekspert",            color: "text-purple-400" },
    { from: 32, to: 999, title: "Legenda",            color: "text-red-400" },
  ];

  const currentMilestone = MILESTONES.find(m => level >= m.from && level <= m.to);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold text-zinc-50 flex items-center gap-2">
          <User size={22} className="text-blue-500" />
          Profil
        </h1>
        <p className="text-zinc-500 text-sm mt-1">Sizning rivojlanish statistikangiz</p>
      </div>

      {/* Profile hero card */}
      <div className="card">
        <div className="flex flex-col sm:flex-row sm:items-center gap-5">
          {/* Avatar */}
          <div className="w-16 h-16 bg-blue-500/10 border-2 border-blue-500/20 rounded-2xl flex items-center justify-center flex-shrink-0">
            <span className="text-3xl font-bold text-blue-400">{initial}</span>
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <h2 className="text-lg font-bold text-zinc-50">
              {profile?.full_name ?? "Foydalanuvchi"}
            </h2>
            <p className="text-zinc-500 text-sm">{user.email}</p>
            <div className="flex flex-wrap gap-2 mt-2">
              <span className="badge border-blue-500/25 bg-blue-500/10 text-blue-400">
                <Star size={11} /> Daraja {level} · {levelTitle}
              </span>
              <span className="badge border-zinc-700 text-zinc-500">
                <Calendar size={11} /> {joinDate} dan beri
              </span>
            </div>
          </div>

          {/* XP progress */}
          <div className="sm:w-44 flex-shrink-0">
            <div className="flex justify-between text-xs text-zinc-600 mb-1.5">
              <span>Daraja {level}</span>
              <span>Daraja {level + 1}</span>
            </div>
            <div className="xp-track h-2">
              <div className="xp-fill h-full" style={{ width: `${pct}%` }} />
            </div>
            <p className="text-xs text-zinc-600 text-center mt-1.5">
              {toNext} XP qoldi
            </p>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div>
        <p className="text-xs font-medium text-zinc-600 uppercase tracking-wider mb-4">Statistika</p>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { Icon: Star,       label: "Daraja",         value: level,       sub: levelTitle,                     color: "text-blue-500",   bg: "bg-blue-500/10" },
            { Icon: Zap,        label: "Jami XP",         value: xp,          sub: `${toNext} XP qoldi`,           color: "text-amber-500",  bg: "bg-amber-500/10" },
            { Icon: Flame,      label: "Streak",          value: `${streakEmoji(streak)} ${streak}`, sub: "Ketma-ket kun", color: "text-orange-500", bg: "bg-orange-500/10" },
            { Icon: CheckSquare,label: "Bajarilgan vazifalar",value: tasksTotal,  sub: "Jami",                   color: "text-emerald-500", bg: "bg-emerald-500/10" },
            { Icon: Target,     label: "Odat bajarilishi",value: habitsTotal,  sub: "Jami marta",               color: "text-purple-500",  bg: "bg-purple-500/10" },
            { Icon: Star,       label: "XP progress",    value: `${pct}/100`, sub: "Joriy daraja",              color: "text-zinc-400",   bg: "bg-zinc-800" },
          ].map((s, i) => (
            <div key={i} className="card">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-8 h-8 ${s.bg} rounded-lg flex items-center justify-center`}>
                  <s.Icon size={15} className={s.color} />
                </div>
              </div>
              <p className="text-2xl font-bold text-zinc-50">{s.value}</p>
              <p className="text-xs text-zinc-400 mt-0.5">{s.label}</p>
              <p className="text-xs text-zinc-600">{s.sub}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Level milestones */}
      <div>
        <p className="text-xs font-medium text-zinc-600 uppercase tracking-wider mb-4">Daraja yo&apos;li</p>
        <div className="card divide-y divide-zinc-800">
          {MILESTONES.map(m => {
            const isReached  = level >= m.from;
            const isCurrent  = level >= m.from && level <= m.to;
            return (
              <div
                key={m.from}
                className={cn(
                  "flex items-center gap-3 py-3 first:pt-0 last:pb-0 transition-opacity",
                  !isReached && "opacity-30"
                )}
              >
                <div className={`w-2 h-2 rounded-full flex-shrink-0 ${isReached ? "bg-blue-500" : "bg-zinc-700"}`} />
                <span className={`text-sm font-medium flex-1 ${isCurrent ? m.color : "text-zinc-400"}`}>
                  {m.title}
                </span>
                <span className="text-xs text-zinc-600 font-mono">
                  Daraja {m.from}–{m.to === 999 ? "∞" : m.to}
                </span>
                {isCurrent && (
                  <span className="badge border-blue-500/25 bg-blue-500/10 text-blue-400">Hozir</span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function cn(...cls: (string | boolean | undefined)[]) {
  return cls.filter(Boolean).join(" ");
}
