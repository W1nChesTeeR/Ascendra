import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import {
  Profile, Task, Habit,
  xpInLevel, xpToNext, streakEmoji,
  getLevelTitle, greeting, todayStr, fmtDate,
  DIFFICULTY_LABEL, DIFFICULTY_XP, DIFFICULTY_COLOR,
} from "@/types";
import {
  Zap, Flame, Star, TrendingUp, CheckCircle2,
  Target, Clock, Plus, ArrowRight,
} from "lucide-react";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const today = todayStr();

  // Parallel fetches
  const [
    { data: profile },
    { data: pendingTasks },
    { data: habits },
    { data: todayCompletions },
  ] = await Promise.all([
    supabase
      .from("profiles")
      .select("*")
      .eq("id", user.id)
      .single<Profile>(),
    supabase
      .from("tasks")
      .select("*")
      .eq("user_id", user.id)
      .eq("is_completed", false)
      .order("created_at", { ascending: false })
      .limit(5),
    supabase
      .from("habits")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(6),
    supabase
      .from("habit_completions")
      .select("habit_id")
      .eq("user_id", user.id)
      .eq("completed_date", today),
  ]);

  const xp           = profile?.xp    ?? 0;
  const level        = profile?.level  ?? 1;
  const streak       = profile?.streak ?? 0;
  const xpNow        = xpInLevel(xp);
  const xpLeft       = xpToNext(xp);
  const levelTitle   = getLevelTitle(level);
  const firstName    = profile?.full_name?.split(" ")[0] ?? "Foydalanuvchi";
  const completedIds = new Set((todayCompletions ?? []).map((c: { habit_id: string }) => c.habit_id));

  const tasks: Task[]   = (pendingTasks ?? []) as Task[];
  const allHabits: Habit[] = (habits ?? []) as Habit[];
  const completedHabitsToday = allHabits.filter(h => completedIds.has(h.id)).length;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* ─── Header ─── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <p className="text-zinc-500 text-sm">
            {new Date().toLocaleDateString("uz-UZ", { weekday: "long", day: "numeric", month: "long" })}
          </p>
          <h1 className="text-2xl font-bold text-zinc-50 mt-0.5">
            {greeting()},{" "}
            <span className="text-blue-500">{firstName}</span>!
          </h1>
        </div>
        {streak > 0 && (
          <div className="inline-flex items-center gap-2 text-sm font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-full">
            <Flame size={15} />
            {streak} kunlik streak
          </div>
        )}
      </div>

      {/* ─── Stats grid ─── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Level */}
        <div className="card col-span-2 lg:col-span-1">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center">
              <Star size={15} className="text-blue-500" />
            </div>
            <span className="text-xs text-zinc-600 font-mono">DARAJA</span>
          </div>
          <p className="text-3xl font-bold text-zinc-50">{level}</p>
          <p className="text-xs text-zinc-500 mt-0.5">{levelTitle}</p>
          <div className="mt-3">
            <div className="flex justify-between text-xs text-zinc-600 mb-1.5">
              <span>{xpNow} XP</span>
              <span>{xpLeft} qoldi</span>
            </div>
            <div className="xp-track">
              <div className="xp-fill" style={{ width: `${xpNow}%` }} />
            </div>
          </div>
        </div>

        {/* XP */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-amber-500/10 rounded-lg flex items-center justify-center">
              <Zap size={15} className="text-amber-500" />
            </div>
            <span className="text-xs text-zinc-600 font-mono">XP</span>
          </div>
          <p className="text-3xl font-bold text-zinc-50">{xp}</p>
          <p className="text-xs text-zinc-500 mt-0.5">Jami tajriba</p>
        </div>

        {/* Streak */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
              <Flame size={15} className="text-orange-500" />
            </div>
            <span className="text-xs text-zinc-600 font-mono">STREAK</span>
          </div>
          <p className="text-3xl font-bold text-zinc-50">
            {streakEmoji(streak)} {streak}
          </p>
          <p className="text-xs text-zinc-500 mt-0.5">Ketma-ket kun</p>
        </div>

        {/* Completed tasks */}
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center">
              <TrendingUp size={15} className="text-emerald-500" />
            </div>
            <span className="text-xs text-zinc-600 font-mono">BAJARILDI</span>
          </div>
          <p className="text-3xl font-bold text-zinc-50">{profile?.tasks_completed ?? 0}</p>
          <p className="text-xs text-zinc-500 mt-0.5">Jami vazifalar</p>
        </div>
      </div>

      {/* ─── Today's tasks ─── */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
            <CheckCircle2 size={16} className="text-blue-500" />
            Faol vazifalar
          </h2>
          <Link
            href="/vazifalar"
            className="flex items-center gap-1 text-xs text-blue-500 hover:text-blue-400 transition-colors"
          >
            Barchasini ko&apos;rish <ArrowRight size={12} />
          </Link>
        </div>

        {tasks.length === 0 ? (
          <div className="card flex flex-col items-center justify-center py-12 text-center">
            <CheckCircle2 size={32} className="text-zinc-700 mb-3" />
            <p className="text-zinc-400 font-medium text-sm">Hozircha vazifa yo&apos;q</p>
            <p className="text-zinc-600 text-xs mt-1 mb-4">Yangi vazifa qo&apos;shing</p>
            <Link href="/vazifalar" className="btn-primary text-xs px-3 py-2">
              <Plus size={14} />
              Vazifa qo&apos;shish
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => (
              <div key={task.id} className="card flex items-center gap-3 py-3.5">
                <div className="w-4 h-4 rounded-full border-2 border-zinc-700 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-zinc-100 truncate">{task.title}</p>
                  {task.due_date && (
                    <p className="flex items-center gap-1 text-xs text-zinc-600 mt-0.5">
                      <Clock size={11} />
                      {fmtDate(task.due_date)}
                    </p>
                  )}
                </div>
                <span className={`badge flex-shrink-0 ${DIFFICULTY_COLOR[task.difficulty]}`}>
                  {DIFFICULTY_LABEL[task.difficulty]} +{DIFFICULTY_XP[task.difficulty]} XP
                </span>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ─── Habits summary ─── */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-semibold text-zinc-200 flex items-center gap-2">
            <Target size={16} className="text-orange-500" />
            Bugungi odatlar
            {allHabits.length > 0 && (
              <span className="text-xs text-zinc-600">
                {completedHabitsToday}/{allHabits.length}
              </span>
            )}
          </h2>
          <Link
            href="/odatlar"
            className="flex items-center gap-1 text-xs text-blue-500 hover:text-blue-400 transition-colors"
          >
            Barchasini ko&apos;rish <ArrowRight size={12} />
          </Link>
        </div>

        {allHabits.length === 0 ? (
          <div className="card flex flex-col items-center justify-center py-12 text-center">
            <Target size={32} className="text-zinc-700 mb-3" />
            <p className="text-zinc-400 font-medium text-sm">Odatlar yo&apos;q</p>
            <p className="text-zinc-600 text-xs mt-1 mb-4">Birinchi odatingizni yarating</p>
            <Link href="/odatlar" className="btn-primary text-xs px-3 py-2">
              <Plus size={14} />
              Odat qo&apos;shish
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {allHabits.map((habit) => {
              const done = completedIds.has(habit.id);
              return (
                <div
                  key={habit.id}
                  className={`card transition-colors ${
                    done ? "border-emerald-500/25 bg-emerald-500/5" : ""
                  }`}
                >
                  <span className="text-2xl block mb-2">{habit.icon ?? "⭐"}</span>
                  <p className="text-sm font-medium text-zinc-100 truncate">{habit.name}</p>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-zinc-600 flex items-center gap-1">
                      <Flame size={11} className="text-orange-500" />
                      {habit.streak} kun
                    </p>
                    {done && (
                      <CheckCircle2 size={14} className="text-emerald-500" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
