"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Task, Difficulty,
  DIFFICULTY_LABEL, DIFFICULTY_XP, DIFFICULTY_COLOR,
  todayStr, fmtDate,
} from "@/types";
import { cn } from "@/lib/utils";
import {
  Plus, CheckCircle2, Circle, Pencil, Trash2,
  X, Loader2, Calendar, Filter, CheckSquare,
} from "lucide-react";

type FilterType = "all" | "today" | "completed";

const FILTER_LABELS: Record<FilterType, string> = {
  all:       "Faol",
  today:     "Bugun",
  completed: "Bajarilgan",
};

const DIFFICULTIES: Difficulty[] = ["oson", "orta", "qiyin", "epik"];

export default function VazifalarPage() {
  const [tasks,    setTasks]    = useState<Task[]>([]);
  const [filter,   setFilter]   = useState<FilterType>("all");
  const [loading,  setLoading]  = useState(true);
  const [saving,   setSaving]   = useState(false);
  const [showModal,setShowModal]= useState(false);
  const [editing,  setEditing]  = useState<Task | null>(null);

  // Form fields
  const [title,       setTitle]       = useState("");
  const [description, setDescription] = useState("");
  const [dueDate,     setDueDate]     = useState("");
  const [difficulty,  setDifficulty]  = useState<Difficulty>("orta");

  // ─── Load ───────────────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true);
    const res  = await fetch(`/api/tasks?filter=${filter}`);
    const data = await res.json();
    setTasks(Array.isArray(data) ? data : []);
    setLoading(false);
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  // ─── Modal helpers ───────────────────────────────────────────────────────────
  function openCreate() {
    setEditing(null);
    setTitle(""); setDescription(""); setDueDate(""); setDifficulty("orta");
    setShowModal(true);
  }

  function openEdit(task: Task) {
    setEditing(task);
    setTitle(task.title);
    setDescription(task.description ?? "");
    setDueDate(task.due_date ?? "");
    setDifficulty(task.difficulty);
    setShowModal(true);
  }

  function closeModal() { setShowModal(false); setEditing(null); }

  // ─── CRUD ────────────────────────────────────────────────────────────────────
  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);

    const body = {
      title:       title.trim(),
      description: description.trim() || null,
      difficulty,
      due_date:    dueDate || null,
    };

    if (editing) {
      await fetch(`/api/tasks/${editing.id}`, {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(body),
      });
    } else {
      await fetch("/api/tasks", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(body),
      });
    }

    setSaving(false);
    closeModal();
    load();
  }

  async function handleComplete(task: Task) {
    await fetch(`/api/tasks/${task.id}`, { method: "PATCH" });
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Bu vazifani o'chirishni tasdiqlaysizmi?")) return;
    await fetch(`/api/tasks/${id}`, { method: "DELETE" });
    load();
  }

  // ─── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-50 flex items-center gap-2">
            <CheckSquare size={22} className="text-blue-500" />
            Vazifalar
          </h1>
          <p className="text-zinc-500 text-sm mt-1">
            Bajarilgan har bir vazifa XP beradi
          </p>
        </div>
        <button onClick={openCreate} className="btn-primary">
          <Plus size={16} /> Vazifa qo&apos;shish
        </button>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter size={14} className="text-zinc-600" />
        {(["all", "today", "completed"] as FilterType[]).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-medium transition-all border",
              filter === f
                ? "bg-blue-600 border-blue-600 text-white"
                : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200"
            )}
          >
            {FILTER_LABELS[f]}
          </button>
        ))}
      </div>

      {/* List */}
      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 size={24} className="animate-spin text-zinc-600" />
        </div>
      ) : tasks.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <CheckCircle2 size={36} className="text-zinc-700 mb-3" />
          <p className="text-zinc-400 font-medium">
            {filter === "completed" ? "Bajarilgan vazifalar yo'q" : "Vazifalar yo'q"}
          </p>
          {filter !== "completed" && (
            <>
              <p className="text-zinc-600 text-sm mt-1">Yangi vazifa qo&apos;shing</p>
              <button onClick={openCreate} className="btn-primary mt-4">
                <Plus size={16} /> Birinchi vazifa
              </button>
            </>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          {tasks.map(task => (
            <div
              key={task.id}
              className={cn(
                "card group flex items-start gap-3 py-4 transition-all",
                task.is_completed && "opacity-60"
              )}
            >
              {/* Complete toggle */}
              {task.is_completed ? (
                <CheckCircle2 size={20} className="text-emerald-500 flex-shrink-0 mt-0.5" />
              ) : (
                <button
                  onClick={() => handleComplete(task)}
                  className="flex-shrink-0 mt-0.5 text-zinc-700 hover:text-emerald-500 transition-colors"
                >
                  <Circle size={20} />
                </button>
              )}

              {/* Content */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className={cn(
                    "text-sm font-medium",
                    task.is_completed ? "line-through text-zinc-600" : "text-zinc-100"
                  )}>
                    {task.title}
                  </p>
                  <span className={`badge text-xs ${DIFFICULTY_COLOR[task.difficulty]}`}>
                    {DIFFICULTY_LABEL[task.difficulty]} · +{DIFFICULTY_XP[task.difficulty]} XP
                  </span>
                </div>
                {task.description && (
                  <p className="text-xs text-zinc-500 mt-1">{task.description}</p>
                )}
                {task.due_date && (
                  <p className="flex items-center gap-1 text-xs text-zinc-600 mt-1">
                    <Calendar size={11} />
                    {fmtDate(task.due_date)}
                  </p>
                )}
              </div>

              {/* Actions */}
              {!task.is_completed && (
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                  <button onClick={() => openEdit(task)} className="btn-ghost p-1.5">
                    <Pencil size={14} />
                  </button>
                  <button
                    onClick={() => handleDelete(task.id)}
                    className="btn-ghost p-1.5 hover:text-red-400"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ─── Modal ─── */}
      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold text-zinc-50">
                {editing ? "Vazifani tahrirlash" : "Yangi vazifa"}
              </h2>
              <button onClick={closeModal} className="btn-ghost p-1.5">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="label">Vazifa nomi *</label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="field"
                  placeholder="Nimani bajarasiz?"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="label">Tavsif</label>
                <textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="field resize-none"
                  rows={2}
                  placeholder="Qo'shimcha ma'lumot..."
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">Muddat</label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    min={todayStr()}
                    className="field"
                  />
                </div>
                <div>
                  <label className="label">Qiyinlik</label>
                  <select
                    value={difficulty}
                    onChange={e => setDifficulty(e.target.value as Difficulty)}
                    className="field-select"
                  >
                    {DIFFICULTIES.map(d => (
                      <option key={d} value={d}>
                        {DIFFICULTY_LABEL[d]} (+{DIFFICULTY_XP[d]} XP)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-1">
                <button type="button" onClick={closeModal} className="btn-secondary flex-1">
                  Bekor
                </button>
                <button
                  type="submit"
                  disabled={saving || !title.trim()}
                  className="btn-primary flex-1"
                >
                  {saving
                    ? <Loader2 size={16} className="animate-spin" />
                    : editing ? "Saqlash" : "Qo'shish"
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
