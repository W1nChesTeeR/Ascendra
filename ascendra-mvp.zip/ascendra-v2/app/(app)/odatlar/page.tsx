"use client";

import { useState, useEffect, useCallback } from "react";
import { Habit, HABIT_XP } from "@/types";
import { cn } from "@/lib/utils";
import {
  Plus, CheckCircle2, Circle, Pencil, Trash2,
  X, Loader2, Flame, Target,
} from "lucide-react";

type HabitWithStatus = Habit & { completed_today: boolean };

const ICONS = [
  "📚","💻","🏃","💧","🎯","🧘","🎸","✍️",
  "🌍","🏋️","🍎","☕","🎨","🔬","📖","🎵",
  "🧠","💪","🌅","🎤","🚴","🌿","🧪","🎭",
];

export default function OdatlarPage() {
  const [habits,    setHabits]   = useState<HabitWithStatus[]>([]);
  const [loading,   setLoading]  = useState(true);
  const [saving,    setSaving]   = useState(false);
  const [completing,setComplet]  = useState<string | null>(null);
  const [showModal, setShowModal]= useState(false);
  const [editing,   setEditing]  = useState<Habit | null>(null);

  // Form
  const [name,        setName]       = useState("");
  const [description, setDescr]      = useState("");
  const [icon,        setIcon]        = useState("⭐");

  // ─── Load ───────────────────────────────────────────────────────────────────
  const load = useCallback(async () => {
    setLoading(true);
    const res  = await fetch("/api/habits");
    const data = await res.json();
    setHabits(Array.isArray(data) ? data : []);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  // ─── Modal ───────────────────────────────────────────────────────────────────
  function openCreate() {
    setEditing(null);
    setName(""); setDescr(""); setIcon("⭐");
    setShowModal(true);
  }

  function openEdit(habit: Habit) {
    setEditing(habit);
    setName(habit.name);
    setDescr(habit.description ?? "");
    setIcon(habit.icon ?? "⭐");
    setShowModal(true);
  }

  function closeModal() { setShowModal(false); setEditing(null); }

  // ─── CRUD ────────────────────────────────────────────────────────────────────
  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);

    const body = { name: name.trim(), description: description.trim() || null, icon };

    if (editing) {
      await fetch(`/api/habits/${editing.id}`, {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(body),
      });
    } else {
      await fetch("/api/habits", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(body),
      });
    }

    setSaving(false);
    closeModal();
    load();
  }

  async function handleComplete(habit: HabitWithStatus) {
    if (habit.completed_today) return;
    setComplet(habit.id);
    await fetch(`/api/habits/${habit.id}/complete`, { method: "POST" });
    setComplet(null);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Bu odatni o'chirishni tasdiqlaysizmi?")) return;
    await fetch(`/api/habits/${id}`, { method: "DELETE" });
    load();
  }

  // ─── Stats ───────────────────────────────────────────────────────────────────
  const total      = habits.length;
  const doneToday  = habits.filter(h => h.completed_today).length;
  const pct        = total > 0 ? Math.round((doneToday / total) * 100) : 0;

  // ─── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-50 flex items-center gap-2">
            <Target size={22} className="text-orange-500" />
            Odatlar
          </h1>
          <p className="text-zinc-500 text-sm mt-1">
            Har bajarilgan odat +{HABIT_XP} XP beradi
          </p>
        </div>
        <button onClick={openCreate} className="btn-primary">
          <Plus size={16} /> Odat qo&apos;shish
        </button>
      </div>

      {/* Today's progress */}
      {total > 0 && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-medium text-zinc-200">Bugungi natija</p>
              <p className="text-xs text-zinc-500 mt-0.5">
                {doneToday} / {total} odat bajarildi
              </p>
            </div>
            <span className="text-xl font-bold text-zinc-50">
              {pct === 100 ? "🎉" : "🔥"} {pct}%
            </span>
          </div>
          <div className="xp-track h-2">
            <div className="xp-fill h-full" style={{ width: `${pct}%` }} />
          </div>
        </div>
      )}

      {/* Habits grid */}
      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 size={24} className="animate-spin text-zinc-600" />
        </div>
      ) : habits.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <Target size={36} className="text-zinc-700 mb-3" />
          <p className="text-zinc-400 font-medium">Odatlar yo&apos;q</p>
          <p className="text-zinc-600 text-sm mt-1">Birinchi odatingizni yarating</p>
          <button onClick={openCreate} className="btn-primary mt-4">
            <Plus size={16} /> Birinchi odat
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {habits.map(habit => (
            <div
              key={habit.id}
              className={cn(
                "card group transition-all duration-200",
                habit.completed_today
                  ? "border-emerald-500/25 bg-emerald-500/5"
                  : "hover:border-zinc-700"
              )}
            >
              {/* Top row */}
              <div className="flex items-start justify-between mb-3">
                <span className="text-3xl">{habit.icon ?? "⭐"}</span>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  {!habit.completed_today && (
                    <button onClick={() => openEdit(habit)} className="btn-ghost p-1.5">
                      <Pencil size={13} />
                    </button>
                  )}
                  <button
                    onClick={() => handleDelete(habit.id)}
                    className="btn-ghost p-1.5 hover:text-red-400"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>

              <p className="text-sm font-medium text-zinc-100 mb-0.5">{habit.name}</p>
              {habit.description && (
                <p className="text-xs text-zinc-500 mb-2">{habit.description}</p>
              )}

              {/* Bottom row */}
              <div className="flex items-center justify-between mt-3">
                <span className="flex items-center gap-1 text-xs text-zinc-600">
                  <Flame size={12} className="text-orange-500" />
                  {habit.streak} kun streak
                </span>

                {habit.completed_today ? (
                  <span className="flex items-center gap-1 text-xs font-medium text-emerald-400">
                    <CheckCircle2 size={14} /> Bajarildi
                  </span>
                ) : (
                  <button
                    onClick={() => handleComplete(habit)}
                    disabled={completing === habit.id}
                    className="flex items-center gap-1 text-xs font-medium text-zinc-500 hover:text-emerald-400 transition-colors disabled:opacity-50"
                  >
                    {completing === habit.id
                      ? <Loader2 size={14} className="animate-spin" />
                      : <Circle size={14} />
                    }
                    Bajarish
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ─── Modal ─── */}
      {showModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 w-full max-w-md animate-slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-base font-semibold text-zinc-50">
                {editing ? "Odatni tahrirlash" : "Yangi odat"}
              </h2>
              <button onClick={closeModal} className="btn-ghost p-1.5">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              {/* Icon picker */}
              <div>
                <label className="label">Belgi tanlang</label>
                <div className="grid grid-cols-8 gap-1.5">
                  {ICONS.map(i => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setIcon(i)}
                      className={cn(
                        "w-9 h-9 text-lg rounded-lg flex items-center justify-center transition-all border",
                        icon === i
                          ? "bg-blue-500/15 border-blue-500/40"
                          : "bg-zinc-800 border-zinc-700 hover:bg-zinc-700"
                      )}
                    >
                      {i}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="label">Odat nomi *</label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="field"
                  placeholder="Masalan: Kitob o'qish, Yugurish..."
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="label">Tavsif</label>
                <input
                  type="text"
                  value={description}
                  onChange={e => setDescr(e.target.value)}
                  className="field"
                  placeholder="Qo'shimcha ma'lumot..."
                />
              </div>

              <div className="flex gap-3 pt-1">
                <button type="button" onClick={closeModal} className="btn-secondary flex-1">
                  Bekor
                </button>
                <button
                  type="submit"
                  disabled={saving || !name.trim()}
                  className="btn-primary flex-1"
                >
                  {saving
                    ? <Loader2 size={16} className="animate-spin" />
                    : editing ? "Saqlash" : "Qo'shish"
                  }
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
