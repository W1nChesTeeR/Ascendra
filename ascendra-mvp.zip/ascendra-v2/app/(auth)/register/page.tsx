"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { Loader2, Eye, EyeOff, Zap, CheckCircle } from "lucide-react";

export default function RegisterPage() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow]         = useState(false);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [done, setDone]         = useState(false);

  const router   = useRouter();
  const supabase = createClient();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 6) {
      setError("Parol kamida 6 ta belgidan iborat bo'lishi kerak.");
      return;
    }
    setLoading(true);
    setError("");

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName } },
    });

    if (signUpError) {
      setError(signUpError.message);
      setLoading(false);
      return;
    }

    if (data.user) {
      // Create profile row
      await supabase.from("profiles").upsert({
        id: data.user.id,
        full_name: fullName,
        xp: 0,
        level: 1,
        streak: 0,
        tasks_completed: 0,
        habits_completed_total: 0,
      });

      // If session exists (email confirm disabled) — go straight to dashboard
      if (data.session) {
        router.push("/dashboard");
        router.refresh();
        return;
      }
    }

    setDone(true);
    setLoading(false);
  }

  if (done) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
        <div className="text-center animate-fade-in max-w-sm">
          <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={26} className="text-emerald-400" />
          </div>
          <h2 className="text-lg font-semibold text-zinc-50 mb-2">Hisob yaratildi!</h2>
          <p className="text-zinc-500 text-sm mb-6">
            Email manzilingizni tasdiqlang, so&apos;ng kiring.
          </p>
          <Link href="/login" className="btn-primary">
            Kirish sahifasiga o&apos;ting
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-sm relative animate-fade-in">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-500/10 border border-blue-500/20 rounded-xl mb-3">
            <Zap size={22} className="text-blue-500" />
          </div>
          <h1 className="text-xl font-bold text-zinc-50 tracking-tight">Ascendra</h1>
          <p className="text-zinc-500 text-sm mt-1">Sayohatingizni boshlang</p>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-7">
          <div className="mb-6">
            <h2 className="text-base font-semibold text-zinc-50">Ro&apos;yxatdan o&apos;tish</h2>
            <p className="text-zinc-500 text-sm mt-0.5">Yangi hisob yarating</p>
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label className="label">To&apos;liq ism</label>
              <input
                type="text"
                value={fullName}
                onChange={e => setFullName(e.target.value)}
                className="field"
                placeholder="Ism Familiya"
                required
              />
            </div>

            <div>
              <label className="label">Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="field"
                placeholder="email@example.com"
                required
                autoComplete="email"
              />
            </div>

            <div>
              <label className="label">Parol</label>
              <div className="relative">
                <input
                  type={show ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="field pr-10"
                  placeholder="Kamida 6 ta belgi"
                  required
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-600 hover:text-zinc-400 transition-colors"
                >
                  {show ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-xs text-red-400">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full mt-1">
              {loading
                ? <Loader2 size={16} className="animate-spin" />
                : <>Hisob yaratish<span className="ml-1">→</span></>
              }
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-zinc-500 mt-5">
          Hisobingiz bormi?{" "}
          <Link href="/login" className="text-blue-500 hover:text-blue-400 font-medium transition-colors">
            Kirish
          </Link>
        </p>
      </div>
    </div>
  );
}
