"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import {
  LayoutDashboard, CheckSquare, Target, User, Zap, LogOut,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Profile, xpInLevel, streakEmoji } from "@/types";

const NAV = [
  { href: "/dashboard", label: "Bosh sahifa",  Icon: LayoutDashboard },
  { href: "/vazifalar", label: "Vazifalar",    Icon: CheckSquare },
  { href: "/odatlar",   label: "Odatlar",      Icon: Target },
  { href: "/profil",    label: "Profil",        Icon: User },
];

export default function AppSidebar({ profile }: { profile: Profile | null }) {
  const pathname = usePathname();
  const router   = useRouter();
  const supabase = createClient();

  async function logout() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  const pct = xpInLevel(profile?.xp ?? 0);
  const initial = (profile?.full_name?.[0] ?? "U").toUpperCase();

  return (
    <aside className="fixed left-0 top-0 h-full w-56 bg-zinc-900 border-r border-zinc-800 flex flex-col z-40">
      {/* Logo */}
      <div className="p-5 border-b border-zinc-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-blue-500/10 border border-blue-500/20 rounded-lg flex items-center justify-center">
            <Zap size={16} className="text-blue-500" />
          </div>
          <span className="font-bold text-zinc-50 tracking-tight">Ascendra</span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {NAV.map(({ href, label, Icon }) => {
          const active =
            pathname === href ||
            (href !== "/dashboard" && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={cn(active ? "nav-link-active" : "nav-link")}
            >
              <Icon size={17} className={active ? "text-blue-500" : ""} />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* User strip */}
      <div className="p-3 border-t border-zinc-800 space-y-2.5">
        {/* XP bar */}
        <div className="px-1">
          <div className="flex justify-between text-xs text-zinc-600 mb-1 font-mono">
            <span>Lv {profile?.level ?? 1}</span>
            <span>{profile?.xp ?? 0} XP</span>
          </div>
          <div className="xp-track">
            <div className="xp-fill" style={{ width: `${pct}%` }} />
          </div>
        </div>

        <div className="flex items-center gap-2.5 px-1">
          <div className="w-7 h-7 rounded-full bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-xs font-bold text-blue-400 flex-shrink-0">
            {initial}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-zinc-200 truncate">
              {profile?.full_name ?? "Foydalanuvchi"}
            </p>
            <p className="text-xs text-zinc-600">
              {streakEmoji(profile?.streak ?? 0)} {profile?.streak ?? 0} kun
            </p>
          </div>
          <button
            onClick={logout}
            title="Chiqish"
            className="text-zinc-600 hover:text-red-400 transition-colors p-1 rounded"
          >
            <LogOut size={14} />
          </button>
        </div>
      </div>
    </aside>
  );
}
